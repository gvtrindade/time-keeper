function editInput(elementId) {
  targetElement = document.getElementById(elementId)
  targetElement.disabled = !targetElement.disabled
}
